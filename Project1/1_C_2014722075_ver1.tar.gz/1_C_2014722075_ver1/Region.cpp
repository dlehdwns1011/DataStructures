#include"Region.h"
using namespace std;

Region::Region()
{
	memset(this->rCodeName.first, 0, sizeof(char) * STR_MAX);
	memset(this->rCodeName.second, 0, sizeof(char) * STR_MAX);
	this->pNext = NULL;
	this->pLeft = NULL;
	this->pRight = NULL;
	this->pDown = NULL;
}

Region::~Region()
{
}

void Region::SetRegionCode(char* region_code)
{//setting RegionCode in region node
	strcpy(rCodeName.first , region_code);
}
void Region::SetRegionName(char* region_name)
{//setting Regionname in region node
	strcpy(rCodeName.second, region_name);
}
void Region::SetNext(Region* pNext)
{//setting next node in 2D linked list
	this->pNext = pNext;
}
void Region::SetLeft(Region* pLeft)
{//setting left node in BST
	this->pLeft = pLeft;
}
void Region::SetRight(Region* pRight)
{//setting right node in BST
	this->pRight = pRight;
}
void Region::SetDown(Employment* pDown)
{//setting employment node under to region node
	this->pDown = pDown;
}
char* Region::GetRegionCode()
{//getting regioncode
	return rCodeName.first;
}
char* Region::GetRegionName()
{//getting regionname
	return rCodeName.second;
}
Region* Region::GetNext()
{//getting next region node
	return pNext;
}
Region* Region::GetLeft()
{//getting left node in BST
	return pLeft;
}
Region* Region::GetRight()
{//getting right node in BST
	return pRight;
}
Employment* Region::GetDown()
{//getting employment node under the region node
	return pDown;
}

