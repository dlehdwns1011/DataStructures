#include "Management.h"
#include<utility>
#include<cstring>

using namespace std;

int main()
{//start main

	Management m; //declare

	m.ReadCommand(); //start Command

	return 0;

}
