#include "BST.h"
#include "iostream"
using namespace std;

BST::BST()
{
	this->root = NULL;
}
BST::~BST()
{
	root = NULL;
}
void BST::SetRoot(Region* pNode)
{//setting root node
	root = pNode;
}
Region* BST::GetRoot()
{//getting root node
	return root;
}
bool BST::Insert(Region* rNode)
{//insert region node in Binary Tree shape
	Region* p = root, *pp;
	while (p) {//find position to insert new node
		pp = p;
		if (strcmp(rNode->GetRegionCode(),p->GetRegionCode())<0)
			p = p->GetLeft();
		else if (strcmp(rNode->GetRegionCode(), p->GetRegionCode())>0)
			p = p->GetRight();
	}
	if (strcmp(rNode->GetRegionCode(),pp->GetRegionCode())<0)
		pp->SetLeft(rNode);
	else if (strcmp(rNode->GetRegionCode(), pp->GetRegionCode())>0)
		pp->SetRight(rNode);
	return 1;
}
Employment* BST::Search(char* region_code)
{//Binary Search Tree
	//find employment node most high in region node
	Region* move = root;
	Employment* move2;
	if (move!=NULL&&!strcmp(root->GetRegionCode(), region_code))
	{//if node want to search is root node
		return root->GetDown();
	}
	else
	{//not root
		move = root;
		while (move != NULL)
		{//find node want to search
			if (strcmp(move->GetRegionCode(), region_code)>0)
			{//move left subtree
				move = move->GetLeft();
			}
			else if (strcmp(move->GetRegionCode(), region_code)<0)
			{//move right subtree
				move = move->GetRight();
			}
			else if(!strcmp(move->GetRegionCode(), region_code))
			{//find!
				return move->GetDown();
			}
		}
	}
	return NULL; //not exist root
}
bool BST::Delete(Region* eNode)
{//delete region node in Binary Tree
	Region* p = root,*q=NULL;

	while (p && strcmp(eNode->GetRegionCode(),p->GetRegionCode()))
	{//move p to node will deleted
		q = p;
		if (-1 == strcmp(eNode->GetRegionCode(), p->GetRegionCode())) p = p->GetLeft();
		else p = p->GetRight();
	}
	if (p->GetLeft() == 0 && p->GetRight() == 0) //p is leaf
	{
		if (q == 0) root = 0;
		else if (q->GetLeft() == p) q->SetLeft(NULL);
		else if (q->GetRight() == p) q->SetRight(NULL);
 		delete p;
		return true;
	}
	else if (p->GetLeft() == 0) //p only has right child
	{
		if (q == 0) root = p->GetRight();
		else if (q->GetLeft() == p) q->SetNext(p->GetRight());
		else q->SetRight(p->GetRight());
		delete p;
		return true;
	}
	else if (p->GetRight() == 0) //p only has left child
	{
		if (q == 0) root = p->GetLeft();
		else if (q->GetLeft() == p) q->SetLeft(p->GetLeft());
		else q->SetRight(p->GetLeft());
		delete p;
		return true;
	}

	//p has left and right child
	Region *prevprev = p, *prev = p->GetLeft(),
		*curr = (p->GetLeft())->GetRight();

	while (curr)
	{//setting each node to delete
		prevprev = prev;
		prev = curr;
		curr = curr->GetRight();
	}
	//find best biggest in left subtree of deleted node
	//and  best biggest displace delete node
	if (prevprev == p)
	{//if not doing while
		prev->SetRight(prevprev->GetRight());
		if (q != NULL)
		{
			if (q->GetRight() == p)
			{
				q->SetRight(prev);
			}
			else
			{
				q->SetLeft(prev);
			}
		}
		else
		{
			SetRoot(prev);
		}
		delete p;
		return true;
	}
	//after while, displace node should deleted to 
	//best biggest in left subtree of deleted node
	prevprev->SetRight((prev->GetLeft()));
	prev->SetLeft(p->GetLeft());
	prev->SetRight(p->GetRight());
	if (q != NULL)
	{
		if (q->GetRight() == p)
		{
			q->SetRight(prev);
		}
		else
		{
			q->SetLeft(prev);
		}
	}
	else
	{
		SetRoot(prev);
	}

	delete p;
	return true;

}
