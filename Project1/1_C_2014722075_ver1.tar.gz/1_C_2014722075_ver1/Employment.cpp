#include "Employment.h"
using namespace std;

Employment::Employment()
{
	memset(this->rCodeName.first, 0, sizeof(char) * STR_MAX);
	memset(this->rCodeName.second, 0, sizeof(char) * STR_MAX);
	memset(this->company, 0, sizeof(char) * STR_MAX);
	memset(this->qualification, 0, sizeof(char) * STR_MAX);
	memset(this->working_condition, 0, sizeof(char) * STR_MAX);
	memset(this->to, 0, sizeof(char) * STR_MAX);
	this->pDown = NULL;
	this->pNext = NULL;
}
Employment::~Employment()
{
	
}
void Employment::SetRegionCode(char* region_code)
{//setting RegionCode
	strcpy(rCodeName.first, region_code);
}
void Employment::SetRegionName(char* region_name)
{//setting Regionname
	strcpy(rCodeName.second, region_name);
}
void Employment::SetCompany(char* company)
{//setting company
	strcpy(this->company, company);
}
void Employment::SetQualification(char* qualification)
{//setting Qualification
	strcpy(this->qualification, qualification);
}
void Employment::SetWorkingCondition(char* working_condition)
{//setting WorkingCondition
	strcpy(this->working_condition, working_condition);
}
void Employment::SetTo(char* to)
{//setting TO
	strcpy(this->to, to);
}
void Employment::SetDown(Employment* pDown)
{//setting employment node under the someting employment node
	this->pDown = pDown;
}
void Employment::SetNext(Employment* pNext)
{////setting employment node beside the someting employment node
	this->pNext = pNext;
}
char* Employment::GetRegionCode()
{//getting regioncode
	return rCodeName.first;
}
char* Employment::GetRegionName()
{//getting regionname
	return rCodeName.second;
}
char* Employment::GetCompany()
{//getting company
	return company;
}
char* Employment::GetQualification()
{//getting Qualification
	return qualification;
}
char* Employment::GetWorkingCondition()
{//getting WorkingCondition
	return working_condition;
}
char* Employment::GetTo()
{//getting TO
	return to;
}
Employment* Employment::GetDown()
{//getting employment node under the someting employment node
	return pDown;
}
Employment* Employment::GetNext()
{//getting employment node beside the someting employment node
	return pNext;
}

