#include "List_Circular.h"
#include <fstream>
using namespace std;

List_Circular::List_Circular()
{
	this->pHead = NULL;
}
List_Circular::~List_Circular()
{
	Employment* move, *move2;
	for (move = pHead->GetNext(); ; move = move2)
	{
		if (move == pHead)
			break;
		move2 = move->GetNext();
		delete move;
	}
	delete pHead;
}
void List_Circular::SetHead(Employment* pNode)
{//setting head node
	pHead = pNode;
	if (pHead->GetNext() == NULL)
	{
		pHead->SetNext(pNode);
	}
}
Employment* List_Circular::GetHead()
{//getting head node
	return pHead;
}
void List_Circular::Insert(Employment* pNode)
{//insert employment node was "TO" is "NE"
	Employment *move;
	for (move = pHead;; move = move->GetNext())
	{//error : already exist same node had regioncode and company 
		if (!strcmp(move->GetRegionCode(), pNode->GetRegionCode()) && !strcmp(move->GetCompany(), pNode->GetCompany()))
		{
			cout << "========= ERROR ========" << endl << " 100 - 2" << endl << " ======================" << endl;
			return;
		}
		if (move->GetNext() == pHead)
		{
			break;
		}
	}
	move->SetNext(pNode);
	pNode->SetNext(pHead);
}
Employment* List_Circular::Delete(Employment* pNode)
{//delete employment node was "NE"
	ofstream foutD;
	foutD.open("OUT_DELETE.txt", ios::app);
	Employment* move; Employment* pmove;
	if (pNode == pHead)
	{//if should deleted node is head in Circular 
		for (move = pHead->GetNext(); ; move = move->GetNext())
		{//to new linked
			if (move == pHead)
				break;
			pmove = move;
		}
		//show data of deleted node
		pmove->SetNext(pHead->GetNext());
		SetHead(pHead->GetNext());
		cout << move->GetRegionCode() << ",";
		cout << move->GetRegionName() << ",";
		cout << move->GetCompany() << ",";
		cout << move->GetQualification() << ",";
		cout << move->GetWorkingCondition() << ",";
		cout << move->GetTo() << endl;
		foutD << move->GetRegionCode() << ",";
		foutD << move->GetRegionName() << ",";
		foutD << move->GetCompany() << ",";
		foutD << move->GetQualification() << ",";
		foutD << move->GetWorkingCondition() << ",";
		foutD << move->GetTo() << endl;
		delete move;
		return pmove;

	}
	//not head
	for (move = pHead; ; move = move->GetNext())
	{//to new linked
		if (move == pNode)
			break;
		pmove = move;
	}
	//show data of deleted node
	pmove->SetNext(pNode->GetNext());
	cout << move->GetRegionCode() << ",";
	cout << move->GetRegionName() << ",";
	cout << move->GetCompany() << ",";
	cout << move->GetQualification() << ",";
	cout << move->GetWorkingCondition() << ",";
	cout << move->GetTo() << endl;
	foutD << move->GetRegionCode() << ",";
	foutD << move->GetRegionName() << ",";
	foutD << move->GetCompany() << ",";
	foutD << move->GetQualification() << ",";
	foutD << move->GetWorkingCondition() << ",";
	foutD << move->GetTo() << endl;

	foutD.close();
	delete move;
	return pmove;

}

