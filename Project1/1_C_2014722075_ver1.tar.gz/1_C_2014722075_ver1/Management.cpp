#include "Management.h"
#include <stack>

using namespace std;

Management::Management()
{
	this->m_2DLL = new List_2D();
	this->m_Circular = new List_Circular();
	this->m_BST = new BST(); 

	//Clear existing out file contents
	ofstream fout1, fout2, fout3;
	fout1.open("OUT_FIND.txt", ios::trunc);
	fout2.open("OUT_DELETE.txt", ios::trunc);
	fout3.open("OUT_PRINT.txt", ios::trunc);
	fout1.close();
	fout2.close();
	fout3.close();
}

Management::~Management()
{//delete all of data in 2D linked list(+BST) and Circular linked list
	if (m_2DLL->GetHead() != NULL) delete m_2DLL;
	if (m_Circular->GetHead() != NULL) delete m_Circular;
}

void Management::ReadCommand()
{//read command 
	ifstream finC,finU;
	char * c = new char[258];
	char *find = new char[10];

	finC.open("IN_Command.txt"); //open command file
	while (finC.getline(c, 30))
	{//carry line in text file
		if (c[0] == 'L')
		{//LOAD menu
			int a; 
			strtok(c, " "); 
			find = strtok(NULL, "\n"); //find filename
			a = LOAD(find); //start LOAD
			if (0 == a)
			{//error : text file of LOAD is not exist
				cout << "======== ERROR ========" << endl <<
				"100-1" << endl << "======================" << endl;//Error
			}
		}
		else if (c[0] == 'F')
		{//FIND menu
			int a;
			Employment move;
			char *find = new char[10];
			strtok(c, " ");
			find = strtok(NULL, "\n"); //find RegionCode
			a = FIND(find); //start FIND
			if (0 == a)
			{//error : TO is 'E' in found regioncode not exist
				cout << "======== ERROR ========" << endl <<
					"300-1" << endl << "======================";
			}
			cout << endl;
		}
		else if (c[0] == 'U')
		{//UPDATE menu
			int a;
			strtok(c, " ");
			find = strtok(NULL, "\n"); //find filename
			a = UPDATE(find); //start UPDATE
			if (0 == a)
			{//error : text file of UPDATE is not exist
				cout << "======== ERROR ========" << endl <<
					"200-1" << endl << "======================";
			}
		}
		else if (c[0] == 'D')
		{//DELETE menu
			int a;
			char *find = new char[10];
			strtok(c, " ");
			find = strtok(NULL, "\n");  //find RegionCode to delete 
			a = DELETE(find); //start DELETE
			if (0 == a)
			{//error : RegionCode to deleted is not exist 
				cout << "======== ERROR ========" << endl <<
					"400-1" << endl << "======================" << endl;//Error
			}
			
		}
		else if (c[0] == 'P')
		{//PRINT menu
			int a;
			a = PRINT(); //start PRINT
			if (0 == a)
			{//error : RegionCode to print is not exist 
				cout << "======== ERROR ========" << endl <<
					"500-1" << endl << "======================" << endl;//Error
			}
		}
		else if (c[0] == 'E')
		{//EXIT menu
			int a;
			if (a = EXIT())
				return;
		}

	}
	delete[] find,c;
}
bool Management::LOAD(char* filename)
{//LOAD
	ifstream finL;
	char * l = new char[100]; char *f = new char[10], *s = new char[10],
		*com = new char[10], *q = new char[10], *w = new char[10], *t = new char[10];
	char *find = new char[20]; //declare
	while (1)
	{//LOAD menu
		finL.open(filename); //open load file
		if (finL.fail())
		{//fail open file
			return false;
		}
		else
		{
			//load
			finL.getline(l, 100);
			finL.getline(l, 100);
			finL.getline(l, 100);

			Region* in = new Region; Region* move;
			Employment* inn = new Employment; Employment* move2;

			while (finL.getline(l, 100))
			{//bring 1 line's data
				strcpy(f, strtok(l, ","));
				strcpy(s, strtok(NULL, ","));
				strcpy(com, strtok(NULL, ","));
				strcpy(q, strtok(NULL, ","));
				strcpy(w, strtok(NULL, ","));
				strcpy(t, strtok(NULL, ",")); //store each data
				if (!strcmp(t, "E"))
				{//TO is "E"
					if (m_2DLL->GetHead() == NULL)
					{//if 2D linked list is empty
						in->SetRegionCode(f); in->SetRegionName(s);
						m_2DLL->SetHead(in); //make region node
						inn->SetRegionCode(f); inn->SetRegionName(s);
						inn->SetCompany(com); inn->SetQualification(q);
						inn->SetWorkingCondition(w); inn->SetTo(t);
						m_2DLL->Insert(inn); //make employment node
					}
					else
					{//not empty
						int count = 0;
						for (move = m_2DLL->GetHead();; move = move->GetNext())
						{//if already had region node
							if (!strcmp(move->GetRegionCode(), f))
							{
								count++;
								Employment* inn = new Employment;
								inn->SetRegionCode(f); inn->SetRegionName(s);
								inn->SetCompany(com); inn->SetQualification(q);
								inn->SetWorkingCondition(w); inn->SetTo(t);
								m_2DLL->Insert(inn); //already region node had same region code -> make employment node
								break;

							}
							if (move->GetNext() == NULL)
							{
								break;
							}
						}
						if (count == 0)
						{//make new region node and employment node
							Region* in = new Region;
							in->SetRegionCode(f); in->SetRegionName(s);
							m_2DLL->Insert(in);
							Employment* inn = new Employment;
							inn->SetRegionCode(f); inn->SetRegionName(s);
							inn->SetCompany(com); inn->SetQualification(q);
							inn->SetWorkingCondition(w); inn->SetTo(t);
							m_2DLL->Insert(inn);
						}
					}
				}
				else
				{//TO is "NE"
					if (m_Circular->GetHead() == NULL)
					{//if Circular linked list is empty
						Employment* inn = new Employment;
						inn->SetRegionCode(f); inn->SetRegionName(s);
						inn->SetCompany(com); inn->SetQualification(q);
						inn->SetWorkingCondition(w); inn->SetTo(t); 
						m_Circular->SetHead(inn); //make employment node and setting head node
					}
					else
					{//not empty
						Employment* inn = new Employment;
						inn->SetRegionCode(f); inn->SetRegionName(s);
						inn->SetCompany(com); inn->SetQualification(q);
						inn->SetWorkingCondition(w); inn->SetTo(t);
						m_Circular->Insert(inn); //make employment node

					}
				}
			}

			cout << endl;
			in = m_2DLL->GetHead();
			m_BST->SetRoot(in);
			while (in = in->GetNext())
			{
				m_BST->Insert(in);

			}//insert region node in BST by using 2D linked list
			break;
		}
	}
	cout << "======= LOAD ========" << endl;
	cout << filename << " LOAD Successful" << endl
		<< "============================" << endl<<endl;
	finL.close();
	delete[] l,find,f,s,com,q,w,t;
	return 1; //complete LOAD
}
bool Management::FIND(char* filename)
{//FIND
		ofstream fout;
		fout.open("OUT_FIND.txt",ios::app); //file print of result
		Employment* node;
		char *file = new char[20];
		node = m_BST->Search(filename); //find employment node by using BST
		if (node == NULL)
		{//if not exist node to find
			return false;
		}
		//show data in node found
		cout << "=====FIND - " << filename << " 지역의 채용중인 기업======" << endl
			<< "지역코드,지역명,기업명,지원자격,근무조건,TO" << endl;
		cout << "======================================================" << endl;
		cout << node->GetRegionCode() << ",";
		cout << node->GetRegionName() << ",";
		cout << node->GetCompany() << ",";
		cout << node->GetQualification() << ",";
		cout << node->GetWorkingCondition() << ",";
		cout << node->GetTo() << endl;
		fout << "=====OUT_FIND - " << filename << " 지역의 채용중인 기업======" << endl
			<< "지역코드,지역명,기업명,지원자격,근무조건,TO" << endl;
		fout << "======================================================" << endl;
		fout << node->GetRegionCode() << ",";
		fout << node->GetRegionName() << ",";
		fout << node->GetCompany() << ",";
		fout << node->GetQualification() << ",";
		fout << node->GetWorkingCondition() << ",";
		fout << node->GetTo() << endl;
		while (node = node->GetDown())
		{//show data of the other employment node under the found node
			cout << node->GetRegionCode() << ",";
			cout << node->GetRegionName() << ",";
			cout << node->GetCompany() << ",";
			cout << node->GetQualification() << ",";
			cout << node->GetWorkingCondition() << ",";
			cout << node->GetTo() << endl;
			fout << node->GetRegionCode() << ",";
			fout << node->GetRegionName() << ",";
			fout << node->GetCompany() << ",";
			fout << node->GetQualification() << ",";
			fout << node->GetWorkingCondition() << ",";
			fout << node->GetTo() << endl;
		}
		fout.close();
		return true;

}
bool Management::DELETE(char* region_code)
{//DELETE
	int a;
	ofstream foutD;
	foutD.open("OUT_DELETE.txt",ios::app); //file print of result
	Employment* node; Region* node2; Employment* d;
	char* find = new char[10];
	node = m_BST->Search(region_code); //find node by using BST
	if (node != NULL)
	{//found should deleted node
		strcpy(find, node->GetRegionCode());
		
		for (node2 = m_2DLL->GetHead(); ; node2 = node2->GetNext())
		{//find region node
			if (!strcmp(node2->GetRegionCode(), region_code))
				break;
			if (!node2->GetNext())
			{
				break;
			}
		}
		a = m_2DLL->Delete(node); //delete in 2D linked list
	}
	else
	{//not exist node
		a = 0;
	}
	Employment* move,*pmove;

	int count = 0;
	for (move = m_Circular->GetHead();move!=NULL ; move = move->GetNext())
	{//delete circular linked list
		if (!strcmp(move->GetRegionCode(), find))
		{
			if (count == 0)
			{//print result
				cout <<endl<<"====DELETE - " << region_code << " 지역의 삭제된 채용마감 기업======" << endl
					<< "지역코드,지역명,기업명,지원자격,근무조건,TO" << endl;
				cout << "======================================================" << endl;

				foutD << endl << "====OUT_DELETE - " << region_code << " 지역의 삭제된 채용마감 기업======" << endl
					<< "지역코드,지역명,기업명,지원자격,근무조건,TO" << endl;
				foutD << "======================================================" << endl;
			}
			d = m_Circular->Delete(move);
			move = d;
			a++;
			count++;
		}
		else if (move->GetNext() == m_Circular->GetHead())
		{//if dont have to delete cuz no have node
			break;
		}
	}
	if (node == NULL && a==0)
	{//not exist node to delete
		foutD.close();
		return false;
	}
	m_BST->Delete(node2); //delete region node in BST
	cout << endl;
	foutD.close();
	delete[] find;
}
bool Management::UPDATE(char* filename)
{//UPDATE
	ifstream finU;
	char *u = new char[100]; 
	char*f = new char[10]; char* com = new char[10];
	char *s = new char[10]; char *q = new char[10];
	char *w = new char[10]; char* t = new char[1];
	finU.open(filename);
	if (finU.fail())
	{//error : text file of UPDATE is not exist
		return false;
	}
	int c = 0,ca=0;
	finU.getline(u, 100); finU.getline(u, 100); finU.getline(u, 100);
	Employment* error;
	while (finU.getline(u, 100)) //bring 1 line data to update 
	{//find error
		ca++;
		strcpy(f, strtok(u, ","));	strcpy(s, strtok(NULL, ","));
		strcpy(com, strtok(NULL, ",")); strcpy(q, strtok(NULL, ","));
		strcpy(w, strtok(NULL, ",")); strcpy(t, strtok(NULL, "\n"));
		if (!strcmp(t, "NE"))
		{//find node will be update is exist or not in BST
			error = m_BST->Search(f);
			if (error == NULL)
			{//not exist : error - dont have region node
				c++;
				cout << "======== ERROR ========" << endl <<
					"200-2" << endl << "======================" << endl;//Error
			}
			else
			{
				while (1)
				{
					if (!strcmp(error->GetCompany(), com))
					{
						break;
					}
					error = error->GetDown();
					if (error == NULL)
					{//not exist : error - dont have employment node
						c++;
						cout << "======== ERROR ========" << endl <<
							"200-2" << endl << "======================" << endl;//Error
						break;
					}
				}
			}
		}
		else
		{//find node will be update is exist or not in Circular
			error = m_Circular->GetHead();
			while (1)
			{
				if (error == NULL)
				{
					cout << "======== ERROR ========" << endl <<
						"200-2" << endl << "======================" << endl;//Error
					c++;
					break;
				}
				if (!strcmp(error->GetCompany(), com)&&!strcmp(error->GetRegionCode(),f))
				{
					break;
				}
				if (error!=NULL&&error->GetNext() == m_Circular->GetHead())
				{//not exist in circular linked list
					c++;
					cout << "======== ERROR ========" << endl <<
						"200-2" << endl << "======================" << endl;//Error
					break;
				}
				error = error->GetNext();
			}

		}
	}
	finU.close();//file close
	if (ca == c)
	{
		return 1;
	}

	finU.open(filename);//new open
	cout << "============UPDATE - 변경된 채용정보=============" << endl
		<< "지역코드, 지역명, 기업명, 지원자격, 근무조건, TO" << endl
		<< "==================================================" << endl;
	int count = 0;
	Employment* up,*pup; Region* d,*pd;
	finU.getline(u, 100); finU.getline(u, 100); finU.getline(u, 100);
	u = new char[100];
	while (finU.getline(u, 100))//bring 1 line data to update 
	{ 
		strcpy(f, strtok(u, ","));	strcpy(s,strtok(NULL, ","));
		strcpy(com, strtok(NULL, ",")); strcpy(q,strtok(NULL, ","));
		strcpy(w,strtok(NULL, ",")); strcpy(t, strtok(NULL, "\n")); //store each data
		if (!strcmp(t, "NE"))
		{//"E" -> "NE"
			for (d = m_2DLL->GetHead(); ; d = d->GetNext())
			{//2d find region
				if (!strcmp(f, d->GetRegionCode()))
				{//found region
					for (up = d->GetDown(); ; up = up->GetDown())
					{//find employment
						if (!strcmp(up->GetCompany(), com))
						{//fount employment
							count++;
							if (up == d->GetDown())
							{//employment is one down of region
								if (up->GetDown() == NULL)
								{//only one employment = region have to delete
									if (d == m_2DLL->GetHead())
									{
										m_2DLL->SetHead(d->GetNext());
										m_BST->Delete(d); //delete region node and new head and root
										up->SetTo("NE");
										up->SetDown(NULL); //update
										m_Circular->Insert(up);//insert in circular
										cout << f << "," << s << "," << com << "," << q << "," << w << "," << t << endl;
										break;
									}
									else
									{
										pd->SetNext(d->GetNext());
										m_BST->Delete(d);//delete region node
										up->SetTo("NE");
										up->SetDown(NULL);//update
										m_Circular->Insert(up);//insert in circular
										cout << f << "," << s << "," << com << "," << q << "," << w << "," << t << endl;
										break;
									}
								}
								d->SetDown(up->GetDown());
								up->SetTo("NE");
								up->SetDown(NULL);
								m_Circular->Insert(up);
								cout << f << "," << s << "," << com << "," << q << "," << w << "," << t << endl;
								break;
							}
							else
							{//region dont have to delete
								pup->SetDown(up->GetDown());
								up->SetTo("NE");
								up->SetNext(NULL);
								m_Circular->Insert(up);
								cout << f << "," << s << "," << com << "," << q << "," << w << "," << t << endl;
								break;
							}
						}
						pup = up;
					}
					break;
				}
				pd = d;
				if (d->GetNext() == NULL)
				{
					break;
				}
			}
		}
		else
		{//"NE" -> "E"
			int count = 0;
			pup = m_Circular->GetHead();
			for (up = pup; ; up = up->GetNext())
			{//find employment node
				if (!strcmp(com, up->GetCompany())&&!strcmp(f,up->GetRegionCode()))
				{//found employment in Circular
					count = 1; int count2 = 0;
					if (up == m_Circular->GetHead())
					{//if head have to update
						for (pup = up; ; pup = pup->GetNext())
						{
							if (pup->GetNext() == m_Circular->GetHead())
							{
								break;
							}
						}
						pup->SetNext(up->GetNext());
						m_Circular->SetHead(up->GetNext()); //new head
						up->SetTo("E");
						up->SetNext(NULL);//update
						cout << f << "," << s << "," << com << "," << q << "," << w << "," << t << endl;
						for (d = m_2DLL->GetHead(); ; d = d->GetNext())
						{//find region node in 2D linked list
							if (!strcmp(d->GetRegionCode(), up->GetRegionCode()))
							{
								m_2DLL->Insert(up);
								break;
							}
							if (d->GetNext() == NULL)
							{
								count2 = 1;
								break;
							}
						}
						if (count2 == 1)
						{//not exist region node
							Region* inn = new Region;
							inn->SetRegionCode(up->GetRegionCode()); 
							inn->SetRegionName(up->GetRegionName());
							m_2DLL->Insert(inn);
							m_2DLL->Insert(up);
							m_BST->Insert(inn);
							
						}
					}
					else
					{//not head
						pup->SetNext(up->GetNext());
						up->SetTo("E");
						up->SetNext(NULL); //update
						cout << f << "," << s << "," << com << "," << q << "," << w << "," << t << endl;
						for (d = m_2DLL->GetHead(); ; d = d->GetNext())
						{//find region node
							if (!strcmp(d->GetRegionCode(), up->GetRegionCode()))
							{
								m_2DLL->Insert(up);
								break;
							}
							if (d->GetNext() == NULL)
							{
								count2 = 1;
								break;
							}
						}
						if (count2 == 1)
						{//not exist region node
							Region* inn = new Region;
							inn->SetRegionCode(up->GetRegionCode());
							inn->SetRegionName(up->GetRegionName());
							m_2DLL->Insert(inn);
							m_2DLL->Insert(up);
							m_BST->Insert(inn);
						}
					}

				}

				if (count == 0&&up->GetNext() == m_Circular->GetHead())
				{//not exist node will be update
					break;
				}
				if (count != 0)
				{//not exist node will be update
					break;
				}
				pup = up;
			}
		}
	}
	delete[] u,f,com,s,q,w,t;
	finU.close();
	cout << endl;
}
bool Management::PRINT()
{//PRINT
	ofstream foutP;
	foutP.open("OUT_PRINT.txt", ios::app);
	stack<Region*> s; //declare stack 
	Region* d = m_BST->GetRoot(); 
	Employment* e;
	int count = 0;
	if (d == NULL)
	{//if not exist region node to print
		return false;
	}
	cout << "=====PRINT - " <<  " 채용중인 기업========" << endl
		<< "지역코드,지역명,기업명,지원자격,근무조건,TO" << endl;
	cout << "======================================================" << endl;
	foutP << "=====OUT_PRINT - " << " 채용중인 기업========" << endl
		<< "지역코드,지역명,기업명,지원자격,근무조건,TO" << endl;
	foutP << "======================================================" << endl;
	while (1)
	{//print using BST inorder
		while (d)
		{
			s.push(d);
			d = d->GetLeft();
		}
		if (s.empty())
		{
			cout << endl;
			return true;
		}
		d = s.top();
		s.pop();
		for (e = d->GetDown(); ; e = e->GetDown())
		{
			//show data
			cout << e->GetRegionCode() << ",";
			cout << e->GetRegionName() << ",";
			cout << e->GetCompany() << ",";
			cout << e->GetQualification() << ",";
			cout << e->GetWorkingCondition() << ",";
			cout << e->GetTo() << endl;
			foutP << e->GetRegionCode() << ",";
			foutP << e->GetRegionName() << ",";
			foutP << e->GetCompany() << ",";
			foutP << e->GetQualification() << ",";
			foutP << e->GetWorkingCondition() << ",";
			foutP << e->GetTo() << endl;
			if (e->GetDown() == NULL)
				break;
		}
		d = d->GetRight();
	}

}
bool Management::EXIT()
{//EXIT
	cout << "EXIT" << endl;
	return true;
}
