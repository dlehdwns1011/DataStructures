#include "List_2D.h"
#include<iostream>
#include <fstream>
using namespace std;

List_2D::List_2D()
{
	this->pHead = NULL;
}
List_2D::~List_2D()
{
	Region* move,*move2;
	Employment* movee,*movee2;
	for (move = pHead;; move = move2)
	{
		if (move == NULL)
			break;
		move2 = move->GetNext();
		for (movee = move->GetDown();; movee = movee2)
		{
			if (movee == NULL)
				break;
			movee2 = movee->GetDown();
			delete movee;
		}
		delete move;
	}
}
void List_2D::SetHead(Region* pNode)
{//setting head node
	this->pHead = pNode;
}
Region* List_2D::GetHead()
{//getting head node
	return this->pHead;
}
void List_2D::Insert(Region* pNode)
{//insert region node
	Region* move;
	for (move = GetHead();; move = move->GetNext())
	{
		if (move->GetNext() == NULL)
		{
			break;
		}
	}
	move->SetNext(pNode);
}
void List_2D::Insert(Employment* pNode)
{//insert employment node under region node
	Region* move;
	Employment* move2; Employment* move3;
	for (move = pHead;; move = move->GetNext())
	{//find region node had same RegionCode with pNode to insert
		if (!strcmp(move->GetRegionCode(), pNode->GetRegionCode()))
		{
			break;
		}
	}
	if (move->GetDown() == NULL)
	{//if region node found dont have employment node
		move->SetDown(pNode);
	}
	else
	{//region node found had already employment node
		for (move2 = move->GetDown();; move2 = move2->GetDown())
		{
			if (!strcmp(move2->GetRegionCode(), pNode->GetRegionCode()) &&!strcmp(move2->GetCompany(), pNode->GetCompany()))
			{//error : already exist same node had egioncode and company 
				cout << "========= ERROR ========" << endl << " 100 - 2" << endl << " ======================" << endl;
				return;
			}
			if (move2->GetDown() == NULL)
			{
				break;
			}
		}
		int count = 0;
		for (move2 = move->GetDown(); move2!=NULL; move2 = move2->GetDown())
		{//sort accoding to company name 
			if (strcmp(move2->GetCompany(), pNode->GetCompany()) > 0)
				break;
			count = 1;
			move3 = move2;
		}
		if (count == 0)
		{
			pNode->SetDown(move->GetDown());
			move->SetDown(pNode);
		}
		else
		{
			move3->SetDown(pNode);
			pNode->SetDown(move2);
		}
		
	}
}
bool List_2D::Delete(Employment* pNode)
{//delete employment node
	ofstream foutD;
	foutD.open("OUT_DELETE.txt", ios::app); //file print
	Region* move; Employment* move2;
	Region* node; Employment* node2;
	char* find = new char[10];
	strcpy(find, pNode->GetRegionCode());
	for (move = pHead;; move = move->GetNext())
	{//find region node had same regioncode
		if (!strcmp(move->GetRegionCode(), find))
		{
			break;
		}
		node = move;
		if (move->GetNext() == NULL)
		{//error : RegionCode to deleted is not exist 
			return false;
		}
	}
	if (move == pHead)
	{//if head node should deteled
		SetHead(move->GetNext());//new head
	}
	else//not head
	node->SetNext(move->GetNext());//new linked
	cout << endl << "====DELETE - " << pNode->GetRegionCode() << " 지역의 삭제된 채용중인 기업======" << endl
		<< "지역코드,지역명,기업명,지원자격,근무조건,TO" << endl;
	cout << "======================================================" << endl;
	foutD << "=====OUT_DELETE - " << pNode->GetRegionCode() << " 지역의 삭제된 채용중인 기업======" << endl
		<< "지역코드,지역명,기업명,지원자격,근무조건,TO" << endl;
	foutD << "======================================================" << endl;
	for (move2 = move->GetDown(); ; move2 = node2)
	{//show data of deleted node
		cout << move2->GetRegionCode() << ",";
		cout << move2->GetRegionName() << ",";
		cout << move2->GetCompany() << ",";
		cout << move2->GetQualification() << ",";
		cout << move2->GetWorkingCondition() << ",";
		cout << move2->GetTo() << endl;
		node2 = move2->GetDown();
		foutD << move2->GetRegionCode() << ",";
		foutD << move2->GetRegionName() << ",";
		foutD << move2->GetCompany() << ",";
		foutD << move2->GetQualification() << ",";
		foutD << move2->GetWorkingCondition() << ",";
		foutD << move2->GetTo() << endl;
		delete move2;
		if (node2 == NULL)
		{
			break;
		}
	}
	foutD.close();
	delete[] find;
	return true; //complete
}


