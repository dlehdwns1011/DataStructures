#include "AVLTree.h"

using namespace std;

bool AVLTree::Insert(Gamedata* pGame){
	//insert AVL
	if (root == NULL)
	{//if root is empty
		root = new AVLNode;
		root->setGD(pGame);
	}
	else
	{
		while(1)
		{//already exist root
			// Phase 1: Locate insertion point for id
			AVLNode *a = root,
				*pa = NULL,
				*p = this->root,
				*pp = NULL,
				*rootSub = NULL;
			while (p != NULL)
			{
				if (p->getBF() != 0) { a = p; pa = pp; }
				if (pGame->getGameid() < p->getGD()->getGameid())
				{
					pp = p;
					p = p->getLeft();
				}
				else if (pGame->getGameid() > p->getGD()->getGameid())
				{
					pp = p;
					p = p->getRight();
				}
				else
				{
					delete pGame;
					return false;
				}
			}

			//Phase 2
			AVLNode *y = new AVLNode;
			y->setGD(pGame);
			y->setLeft(NULL);
			y->setRight(NULL); //insert gamedata in new node
			if (pGame->getGameid() < pp->getGD()->getGameid())
				pp->setLeft(y);
			else                       //insert node
				pp->setRight(y);
			
			int d;
			AVLNode *b, *c; //reset balance factor from root
			if (pGame->getGameid() > a->getGD()->getGameid())
			{
				p = a->getRight();
				b = p;
				d = -1;
			}
			else
			{
				p = a->getLeft();
				b = p;
				d = 1;
			}
			while (p != y)
			{
				if (pGame->getGameid() > p->getGD()->getGameid())
				{
					p->setBF(-1);
					p = p->getRight();
				}
				else
				{
					p->setBF(1);
					p = p->getLeft();
				}
			}

			//Is tree unbalanced?
			if (a->getBF() == 0 || a->getBF() + d == 0)
			{//tree still balanced
				a->setBF(a->getBF() + d);
				break;
			}
			//tree unbalanced, determine rotation type
			if (d == 1)
			{//left imbalance
				if (b->getBF() == 1)
				{//rotation type LL
					a->setLeft(b->getRight());
					b->setRight(a);
					a->setBF(0);
					b->setBF(0);
					rootSub = b;
				}
				else
				{//rotation type LR
					c = b->getRight();
					b->setRight(c->getLeft());
					a->setLeft(c->getRight());
					c->setLeft(b);
					c->setRight(a);
					switch (c->getBF())
					{
					case 0:
						b->setBF(0); a->setBF(0);
						break;
					case 1:
						a->setBF(-1); b->setBF(0);
						break;
					case -1:
						b->setBF(1); a->setBF(0);
						break;
					}
					c->setBF(0); rootSub = c;//c is the new root of the subtree
				}//end of LR
			}//end of left imbalance
			else
			{//right imbalance : this is symmetric to left imbalance
				if (b->getBF() == -1)
				{//rotation type RR
					a->setRight(b->getLeft());
					b->setLeft(a);
					a->setBF(0);
					b->setBF(0);
					rootSub = b;//b is the new root of the subtree
				}
				else
				{//rotation type RL
					c = b->getLeft();
					b->setLeft(c->getRight());
					a->setRight(c->getLeft());
					c->setRight(b);
					c->setLeft(a);
					switch (c->getBF())
					{
					case 0:
						b->setBF(0); a->setBF(0);
						break;
					case 1:
						b->setBF(-1); a->setBF(0);
						break;
					case -1:
						a->setBF(1); b->setBF(0);
						break;
					}
					c->setBF(0); rootSub = c;//c is the new root of the subtree
				}//end of RL
			}
			//Subtree with root b has been rebalanced
			if (pa == NULL) root = rootSub;
			else if (a == pa->getLeft()) pa->setLeft(rootSub);
			else pa->setRight(rootSub);
			break;
		}
	}
	return true;
}

void AVLTree::Print(){//print all of gamedata
	stack<AVLNode*> s; //declare stack 
	AVLNode* d = root;
	Gamedata* e; char** team;
	ofstream fout;
	fout.open("log.txt", ofstream::app);
	cout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	cout << "                                                   PRINT GAME" << endl;
	cout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	cout << "Gameid	Duration  Winner	TeamA_c1 Team_c2 Team_c3 Team_c4 Team_c5		TeamB_c1 TeamB_c2 TeamB_c3 TeamB_c4 TeamB_c5" << endl;
	fout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	fout << "                                                   PRINT GAME" << endl;
	fout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	fout << "Gameid	Duration  Winner	TeamA_c1 Team_c2 Team_c3 Team_c4 Team_c5		TeamB_c1 TeamB_c2 TeamB_c3 TeamB_c4 TeamB_c5" << endl;
	while (1)
	{//print using AVLTree inorder
		while (d)
		{//push node in stack from root to mostleft leaf node
			s.push(d);
			d = d->getLeft();
		}
		if (s.empty())
		{//if stack is empty, end function
			cout << endl; fout << endl;
			fout.close();
			return;
		}
		d = s.top(); //return data of top of stack
		s.pop(); //delete data of top of stack
		e = d->getGD();
		//print
		cout << endl << e->getGameid() << "	"; fout << endl << e->getGameid() << "	";
		cout << e->getDuration() << "	"; fout << e->getDuration() << "  	";
		cout << e->getWinner() << "		"; fout << e->getWinner() << "		";//show data
		team = e->getTeamA(); 
		for (int i = 0; i < 5; i++)
		{//print team A
			cout << team[i]; fout << team[i];
			if (i != 4)
				cout << " "; fout << "  ";
		}
		cout << "		"; fout << "		";
		team = e->getTeamB();
		for (int i = 0; i < 5; i++)
		{//print Team B
			cout << team[i]; fout << team[i];
			if (i != 4)
				cout << " "; fout << "  ";
		}
		d = d->getRight(); //go to right of d
	}

}

Gamedata* AVLTree::Search(int id){

	AVLNode* move = root;
	Gamedata* search;
	int c = 0; //declare
	if (move != NULL && root->getGD()->getGameid() == id)
	{//if node want to search is root node
		c = 1;
		search = root->getGD();
		return search;
	}
	else
	{//not root
		while (move != NULL)
		{//find node want to search
			if (move->getGD()->getGameid() > id)
			{//move left subtree
				move = move->getLeft();
			}
			else if (move->getGD()->getGameid() < id)
			{//move right subtree
				move = move->getRight();
			}
			else if (move->getGD()->getGameid() == id)
			{//find!
				c = 1;
				search = move->getGD();
				return search; //return gamedata is id
			}
		}
	}

	return NULL;
}



