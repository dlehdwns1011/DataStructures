#include "Manager.h"
#include <fstream>
#include <cstring>
#include <cstdlib>

using namespace std;

Manager::Manager(int bpOrder) {
	this->avl = new AVLTree();
	this->bp = new BpTree(bpOrder);
}

Manager::~Manager() {
	delete avl;
	delete bp;
}

void Manager::run(const char* command_txt) {

	ifstream finC;
	char *c = new char[100];
	char *find = new char[10];
	int id;
	finC.open(command_txt); //open command file
	while (finC.getline(c, 100))
	{//carry line in command text file
		if (c[0] == 'L')
		{//LOAD Menu
			strtok(c, " ");
			find = strtok(NULL, "\n"); //find filename
			if (LOAD(find) == false)
			{//error in LOAD
				printErrorCode(100);
			}
			else
			{//load complete
				cout << "---------------------------------------------------------------------------------------------------------------------" << endl;
				cout << "                                                    LOAD" << endl;
				cout << "---------------------------------------------------------------------------------------------------------------------" << endl;
				cout << find<<endl<<endl;
				ofstream fout;
				fout.open("log.txt", ofstream::app);
				fout << "---------------------------------------------------------------------------------------------------------------------" << endl;
				fout << "                                                    LOAD" << endl;
				fout << "---------------------------------------------------------------------------------------------------------------------" << endl;
				fout << find << endl << endl;
				fout.close();
			}
		}
		if (c[0] == 'S')
		{//Search Menu
			strtok(c, "_");
			if (!strcmp(strtok(NULL, " "),"GAME"))
			{//search game
				id = atoi(strtok(NULL, "\n"));
				if (SEARCH_GAME(id) == false)
				{//error in Search Game - not exist id
					printErrorCode(300);
				}
			}
			else
			{//search character
				find = strtok(NULL, "\n");
				char* Charactername1 = strtok(find,"/"); //start character name
				char* Charactername2 = strtok(NULL,"\n");//end character name
				if (SEARCH_CHARACTER(Charactername1, Charactername2) == false)
				{//error in Search Character - not exist character(start or end or start ans end)
					printErrorCode(400);
				}

			}
		}
		if (c[0] == 'P')
		{//Print Menu
			strtok(c, "_");
			find = strtok(NULL, "\n");
			if (!strcmp(find, "GAME"))
			{//print game
				if (PRINT_GAME() == false)
					printErrorCode(500);//error in Print Game - not exist Gamedata
			}
			else if(!strcmp(find, "PICK"))
			{//print pick
				if (PRINT_PICK() == false)
				{
					printErrorCode(700);//error in Print Pick - not exist Characterdata
				}
			}
			else if (!strcmp(find, "CHARACTER"))
			{//print character
				if (PRINT_CHARACTER()==false)
				{
					printErrorCode(600);//error in Print Character - not exist Characterdata
				}
			}
			else
			{//print winratio
				if (PRINT_WINRATIO() == false)
				{
					printErrorCode(800);//error in Print Winratio - not exist Characterdata
				}
			}
		}
		if (c[0] == 'U')
		{//Update Menu
			strtok(c, " ");
			char* file = strtok(NULL, "\n");
			if (UPDATE(file) == NULL)
			{
				printErrorCode(200);//error in update !
			}

		}


		if (c[0] == 'E')
		{//Exit
			finC.close();
			delete[] c, find;
			return;
		}
	}
}

bool Manager::LOAD(char* loadfile) {

	if (avl->getRoot() != NULL)
	{//already complete load - error
		return false;
	}
	ifstream finL;
	char* token = new char[20];
	int id, d, w;
	finL.open(loadfile); //open LOAD file
	if (finL.fail())
	{//not exist file - error
		return false;
	}
	char* l = new char[258];
	finL.getline(l, 258);
	while (finL.getline(l, 258))
	{//bring 1 line of data
		//insert AVL Tree
		Gamedata* g = new Gamedata;
		id = atoi(strtok(l, "	")); g->setGameid(id);
		d = atoi(strtok(NULL, "	")); g->setDuration(d);
		w = atoi(strtok(NULL, "	")); g->setWinner(w);
		strcpy(token, strtok(NULL, "	")); g->setTeamA(token, 0);
		strcpy(token, strtok(NULL, "	")); g->setTeamA(token, 1);
		strcpy(token, strtok(NULL, "	")); g->setTeamA(token, 2);
		strcpy(token, strtok(NULL, "	")); g->setTeamA(token, 3);
		strcpy(token, strtok(NULL, "	")); g->setTeamA(token, 4);
		strcpy(token, strtok(NULL, "	")); g->setTeamB(token, 0);
		strcpy(token, strtok(NULL, "	")); g->setTeamB(token, 1);
		strcpy(token, strtok(NULL, "	")); g->setTeamB(token, 2);
		strcpy(token, strtok(NULL, "	")); g->setTeamB(token, 3);
		strcpy(token, strtok(NULL, "\n")); g->setTeamB(token, 4);
		//insert each data in new Gamedata node
		if (avl->Insert(g) == false)
		{
			printErrorCode(100);//error in insert - already exist gamedata of id
		}
		else
		{//insert BpTree
			if (g->getWinner() == 0)
			{//if winner is team A
				char** name = g->getTeamA();
				char** name2 = g->getTeamB();
				for (int h = 0; h <= 4; h++)
				{//insert characters of Team A
					Characterdata* d = new Characterdata;
					d->setname(name[h]);
					d->setpickinc();
					d->setwininc(); //insert each information of Character
					bp->Insert(d); //insert in BpTree

				//insert characters of Team B
					Characterdata* f = new Characterdata;
					f->setname(name2[h]);
					f->setpickinc();//insert each information of Character
					bp->Insert(f);//insert in BpTree
				}
			}			
			else
			{	//if winner is team B
				char** name = g->getTeamB();
				char** name2 = g->getTeamA();
				for (int h = 0; h <= 4; h++)
				{//insert characters of Team B
					Characterdata* d = new Characterdata;
					d->setname(name[h]);
					d->setpickinc();
					d->setwininc();//insert each information of Character
					bp->Insert(d);//insert in BpTree

				//insert characters of Team A
					Characterdata* f = new Characterdata;
					f->setname(name2[h]);
					f->setpickinc();//insert each information of Character
					bp->Insert(f);//insert in BpTree
				}
			}
		}
	}
	finL.close(); //file close
	delete[] token, l;
	return true;//file load complete
}

bool Manager::UPDATE(char* updatefile) {
	
	Gamedata* game; Gamedata* bf_g;
	Characterdata* cha;
	AVLNode* avlnode;
	BpTreeNode* Bpnode;
	map<string, Characterdata*>* m; 
	map<string, Characterdata*>::iterator it_char; //declare
	if (avl->getRoot() == NULL)
		return false; //error if no data in trees
	ifstream fin;
	ofstream fout;
	fin.open(updatefile); //file open
	if (fin.fail())
		return false; //if file not exist, error
	fout.open("log.txt", ofstream::app);
	cout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	cout << "                                                   UPDATE" << endl;
	cout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	cout << "Gameid	Duration  Winner	TeamA_c1 Team_c2 Team_c3 Team_c4 Team_c5		TeamB_c1 TeamB_c2 TeamB_c3 TeamB_c4 TeamB_c5" << endl;
	fout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	fout << "                                                   UPDATE" << endl;
	fout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	fout << "Gameid	Duration  Winner	TeamA_c1 Team_c2 Team_c3 Team_c4 Team_c5		TeamB_c1 TeamB_c2 TeamB_c3 TeamB_c4 TeamB_c5" << endl;
	char* l = new char[258];
	char* l2 = new char[258];
	char* token = new char[20];
	int id, d, w;
	fin.getline(l, 258);
	while (fin.getline(l, 258))
	{//get 1 line in update file
		strcpy(l2, l);
		id = atoi(strtok(l, "	")); //id
		if (avl->Search(id) == NULL)
		{//if id will be updated is not exist - error
			return false;
		}
		cout << l2 << endl;
		fout << l2 << endl;
		game = avl->Search(id); //find gamedata
		d = atoi(strtok(NULL, "	")); //duration
		game->setDuration(d); //update duration
		char** name = game->getTeamA();
		char** name2 = game->getTeamB();
		if (!game->getWinner())//if winner is Team A before update
		{
			for (int i = 0; i <= 4; i++)
			{//Team A - pick--, win--
				Bpnode = bp->searchDataNode(name[i]);
				m = Bpnode->getDataMap();
				for (it_char = m->begin(); it_char->first != name[i]; it_char++);
				cha = it_char->second;
				cha->setpickdec();
				cha->setwindec();
			}
			for (int i = 0; i <= 4; i++)
			{//Team B - pick--
				Bpnode = bp->searchDataNode(name2[i]);
				m = Bpnode->getDataMap();
				for (it_char = m->begin(); it_char->first != name2[i]; it_char++);
				cha = it_char->second;
				cha->setpickdec();
			}
		}
		else // if winner is Team B before updata
		{
			for (int i = 0; i <= 4; i++)
			{//Team B - pick--,win--
				Bpnode = bp->searchDataNode(name2[i]);
				m = Bpnode->getDataMap();
				for (it_char = m->begin(); it_char->first != name2[i]; it_char++);
				cha = it_char->second;
				cha->setpickdec();
				cha->setwindec();
			}
			for (int i = 0; i <= 4; i++)
			{//Team A - pick--
				Bpnode = bp->searchDataNode(name[i]);
				m = Bpnode->getDataMap();
				for (it_char = m->begin(); it_char->first != name[i]; it_char++);
				cha = it_char->second;
				cha->setpickdec();
			}
		}
		w = atoi(strtok(NULL, "	")); //winner
		game->setWinner(w); //update winner
		strcpy(token, strtok(NULL, "	")); game->setTeamA(token, 0);
		strcpy(token, strtok(NULL, "	")); game->setTeamA(token, 1);
		strcpy(token, strtok(NULL, "	")); game->setTeamA(token, 2);
		strcpy(token, strtok(NULL, "	")); game->setTeamA(token, 3);
		strcpy(token, strtok(NULL, "	")); game->setTeamA(token, 4);
		strcpy(token, strtok(NULL, "	")); game->setTeamB(token, 0);
		strcpy(token, strtok(NULL, "	")); game->setTeamB(token, 1);
		strcpy(token, strtok(NULL, "	")); game->setTeamB(token, 2);
		strcpy(token, strtok(NULL, "	")); game->setTeamB(token, 3);
		strcpy(token, strtok(NULL, "\n")); game->setTeamB(token, 4); //update character

		//reinsert in BpTree to update
		if (game->getWinner() == 0)
		{//if winner is team A
			char** name = game->getTeamA();
			char** name2 = game->getTeamB();
			for (int h = 0; h <= 4; h++)
			{//insert characters of Team A
				Characterdata* d = new Characterdata;
				d->setname(name[h]);
				d->setpickinc();
				d->setwininc(); //insert each information of Character
				bp->Insert(d); //insert in BpTree

							   //insert characters of Team B
				Characterdata* f = new Characterdata;
				f->setname(name2[h]);
				f->setpickinc();//insert each information of Character
				bp->Insert(f);//insert in BpTree
			}
		}
		else
		{	//if winner is team B
			char** name = game->getTeamB();
			char** name2 = game->getTeamA();
			for (int h = 0; h <= 4; h++)
			{//insert characters of Team B
				Characterdata* d = new Characterdata;
				d->setname(name[h]);
				d->setpickinc();
				d->setwininc();//insert each information of Character
				bp->Insert(d);//insert in BpTree

							  //insert characters of Team A
				Characterdata* f = new Characterdata;
				f->setname(name2[h]);
				f->setpickinc();//insert each information of Character
				bp->Insert(f);//insert in BpTree
			}
		}
	}
	delete[] l, l2, token;
	fin.close(); fout.close(); //file close
	return true;//file update complete

}

bool Manager::SEARCH_GAME(int id1) {
	//find GameData of id
	ofstream fout;
	fout.open("log.txt", ofstream::app);
	Gamedata* search;
	char** team;
	search = avl->Search(id1);
	if(search == NULL)
	{//can not find game id - error
		return false;
	}
	cout << "---------------------------------------------------------------------------------------------------------------------" << endl
		<< "                                                  SEARCH " << id1 << endl;
	cout << "---------------------------------------------------------------------------------------------------------------------" << endl;
	fout << "---------------------------------------------------------------------------------------------------------------------" << endl
		<< "                                                  SEARCH " << id1 << endl;
	fout << "---------------------------------------------------------------------------------------------------------------------" << endl;
	cout << "Gameid : " << search->getGameid() << endl; //print gameid
	cout << "Duration : " << search->getDuration() << endl;//print Duration of game
	cout << "Winner : " << search->getWinner() << endl;//print winner of game
	fout << "Gameid : " << search->getGameid() << endl; //print gameid
	fout << "Duration : " << search->getDuration() << endl;//print Duration of game
	fout << "Winner : " << search->getWinner() << endl;//print winner of game
	team = search->getTeamA();
	cout << "Team A : ";
	fout << "Team A : ";
	for (int i = 0; i < 5; i++)
	{//print team A of Game
		cout << team[i];
		fout << team[i];
		if (i != 4)
		{
			cout << "/";
			fout << "/";
		}
	}
	team = search->getTeamB();
	cout << endl << "Team B : ";
	fout << endl << "Team B : ";
	for (int i = 0; i < 5; i++)
	{//print team B of Game
		fout << team[i];
		cout << team[i];
		if (i != 4)
		{
			cout << "/";
			fout << "/";
		}
	}
	cout << endl; fout << endl;
	fout.close();
	return true;//game search complete
}

bool Manager::SEARCH_CHARACTER(char* Charactername1, char* Charactername2) {
	//print all of CharacterData from start Character to end
	BpTreeNode* charac1 = bp->searchDataNode(Charactername1); //find datanode of start character
	BpTreeNode* charac2 = bp->searchDataNode(Charactername2); //find datanode of end character
	if (charac1 == NULL || charac2 == NULL)
	{//not exist character - error
		return false;
	}
	char* temp;
	if (strcmp(Charactername1, Charactername2) > 0)
	{//if Char1 > Char2 -> change position
		bp->SearchRange(Charactername2, Charactername1); //go to BpTree SearchRange
		return true;//character search complete
	}
	bp->SearchRange(Charactername1, Charactername2); //go to BpTree SearchRange
	return true;//character search complete
}

bool Manager::PRINT_GAME() {
	//print all of gamedata in AVLTree
	if (avl->getRoot() == NULL)
	{
		return false;//not exist gamedata in AVLTree
	}
	avl->Print();//go to print function of avl
	return true;//print Game in gameid ascending order(id	winner	duration	teama	teamb)
}

bool Manager::PRINT_CHARACTER() {
	//print all of Characterdata in Bptree
	if (bp->getRoot() == NULL)
	{
		return false;//not exist characterdata in BpTree
	}
	bp->Print();//go to print function of bp
	return true;//charater print complete
}

bool Manager::PRINT_PICK() {
	if (!bp->getRoot())
		return false; //if BpTree is empty , error
	bp->printPickRank();

	return true;//print complete(no print return false)
}

bool Manager::PRINT_WINRATIO() {
	if (!bp->getRoot())
		return false; //if BpTree is empty , error
	bp->printRatioRank();
	return true;//print complete(no print return false)
}

void Manager::printErrorCode(int n) {
	ofstream fout; //print error code <n>
	fout.open("log.txt", ofstream::app);
	fout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	fout << "                                                       ERROR                                                         " << endl;
	fout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	fout << n << endl;
	cout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	cout << "                                                       ERROR                                                         " << endl;
	cout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	cout << n << endl;
	fout.close();
}

