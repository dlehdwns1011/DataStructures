#include "Manager.h"
#include <stdio.h>

using namespace std;

int main()
{
	Manager k(3);
	k.run("command_list.txt");

    return 0;
}

