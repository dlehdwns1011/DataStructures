#include "BpTree.h"

using namespace std;

bool BpTree::Insert(Characterdata* new_Character){
	//insert Charaterdata in BpTree
	map<string, BpTreeNode*>::iterator it_index;
	map<string, Characterdata*>::iterator it_char;
	map<string, BpTreeNode*>* m_bp;
	map<string, Characterdata*>* m_char; //declare

	Characterdata* up;
	BpTreeNode* p = root;
	BpTreeNode* b; //declare


	b = searchDataNode(new_Character->getname()); 
	//find Characterdata for update

	if (b != NULL)
	{//Character data already exist
		m_char = b->getDataMap();
		it_char = m_char->begin();
		for (; it_char->first != new_Character->getname(); it_char++) {}//find map had characterdata
		if (new_Character->getwin() == 1)
		{//if character in winner team
			it_char->second->setpickinc(); //pick++
			it_char->second->setwininc(); //win++
			delete new_Character;//dont have to insert -> delete
			return false;//updata win, pick
		}
		else
		{//if character in loser team
			it_char->second->setpickinc(); //pick++
			delete new_Character;//dont have to insert -> delete
			return false; //updata win, pick
		}
	}
	//Character data not exist -> insert new characterdata
	while (1)
	{
		if (!root)
		{//if root is not exist
			p = new BpTreeDataNode; //new datanode
			p->insertDataMap(new_Character->getname(), new_Character);//insert map of character in datanode
			root = p;//set root
			break;
		}

		while (p->getMostLeftChild())
		{//root is exist and find datanode can insert new character map
			it_index = p->getIndexMap()->begin();
			if (it_index->first > new_Character->getname())
			{//case of mostleft path
				p = p->getMostLeftChild();
			}
			else
			{//case of the other path
				for (; it_index->first <= new_Character->getname(); )	
				{
					if (++it_index == p->getIndexMap()->end())
					{
						break;
					}
				}
				it_index--;
				p = it_index->second;
			}
		}
		//found datanode can insert new map
		
		p->insertDataMap(new_Character->getname(), new_Character);//insert new map
		if (exceedDataNode(p))
		{//if datanode need to split (mapsize >= order)
			splitDataNode(p);
		}
		break;
	}


	return true;//no duplication
}

BpTreeNode * BpTree::searchDataNode(string n) {
	
	BpTreeNode* pCur = root;
	map<string, BpTreeNode*>::iterator it_index;
	map<string, Characterdata*>::iterator it_char;
	map<string, Characterdata*>* m; //declare
	while (1)
	{
		if (pCur == NULL)
		{//if root of BpTree not exist - error
			break;
		}
		while (pCur->getMostLeftChild())
		{//find datanode had characterdata of n(character name)
			it_index = pCur->getIndexMap()->begin();
			if (it_index->first > n)
			{//case of mostleft path
				pCur = pCur->getMostLeftChild();
			}
			else
			{//case of the other path
				for (; it_index != pCur->getIndexMap()->end();it_index++)
				{
					if (it_index->first > n)
						break;
				}
				it_index--;
				pCur = it_index->second;
			}
		}
		m = pCur->getDataMap();
		it_char = m->begin();
		for (; it_char != m->end(); it_char++)
		{//find map had characterdata in datanode
			if (it_char->first == n)
			{
				return pCur;//find!
			}
		}
		break;
	}

	return NULL;//cant find
}

void BpTree::splitDataNode(BpTreeNode* pDataNode) {
	int splitPosition = ceil((order - 1) / 2.0) + 1;
	map<string, Characterdata*> *m;
	m = pDataNode->getDataMap(); //declare
	map<string, Characterdata*>::iterator it_char; 
	map<string, BpTreeNode*>::iterator it_index;
	BpTreeNode* l = new BpTreeDataNode;
	int count = 1;//declare
	for (it_char = m->begin(); count != splitPosition; count++)
	{//find map will be split and make new node
		l->insertDataMap(it_char->first, it_char->second);
		pDataNode->deleteMap(it_char->first);
		it_char = m->begin();
	}
	if (pDataNode->getParent() == NULL)
	{//no parent, only root node case
		BpTreeNode* parent = new BpTreeIndexNode;
		parent->insertIndexMap(it_char->first,pDataNode);
		parent->setMostLeftChild(l);
		pDataNode->setParent(parent);
		l->setParent(parent);
		l->setNext(pDataNode);
		pDataNode->setPrev(l);//set new link
		root = parent; //set new root
	}
	else
	{//have parent node
		BpTreeNode* parent = pDataNode->getParent();
		parent->insertIndexMap(it_char->first, pDataNode);
		if (pDataNode == pDataNode->getParent()->getMostLeftChild())
		{//mostleftchild will be split
			parent->setMostLeftChild(l);
			l->setNext(pDataNode);
			l->setParent(parent);
			l->setPrev(pDataNode->getPrev());
			if(pDataNode->getPrev()!=NULL)
				pDataNode->getPrev()->setNext(l);
			pDataNode->setPrev(l);//set new link
		}
		else
		{//the others child will be split
			it_index = parent->getIndexMap()->begin();
			for (; it_index->first != it_char->first; it_index++) {}
			it_index--;
			it_index->second = l;
			l->setNext(pDataNode);
			l->setParent(parent);
			l->setPrev(pDataNode->getPrev());
			if (pDataNode->getPrev()!=NULL)
				pDataNode->getPrev()->setNext(l);
			pDataNode->setPrev(l);//set new link
		}
		if(exceedIndexNode(parent))
		{//indexNode have to split
			splitIndexNode(parent);
		}
	}

}

void BpTree::splitIndexNode(BpTreeNode* pIndexNode){
	int splitPosition = ceil((order - 1) / 2.0) + 1;
	map<string, BpTreeNode*>::iterator it_index;
	map < string, BpTreeNode*> *m = pIndexNode->getIndexMap();
	BpTreeNode* l = new BpTreeIndexNode;
	BpTreeNode* parent = pIndexNode->getParent();
	int count = 1;//declare
	for (it_index = m->begin(); count != splitPosition; count++)
	{//find index map will be split and make new node
		it_index->second->setParent(l);
		l->insertIndexMap(it_index->first, it_index->second);
		pIndexNode->deleteMap(it_index->first);
		it_index = m->begin();
	}
	l->setMostLeftChild(pIndexNode->getMostLeftChild());
	l->getMostLeftChild()->setParent(l); //new link
	if (!parent)
	{//no parent
		parent = new BpTreeIndexNode;
		parent->setMostLeftChild(l);
		l->setParent(parent);
		pIndexNode->setMostLeftChild(it_index->second);
		parent->insertIndexMap(it_index->first, pIndexNode);
		pIndexNode->deleteMap(it_index->first);
		pIndexNode->setParent(parent);//set new link
		root = parent;//set new root
	}
	else if (pIndexNode->getParent()->getMostLeftChild() == pIndexNode)
	{//pIndexNode is mostleftchild of parent node
		parent->setMostLeftChild(l);
		l->setParent(parent);
		pIndexNode->setMostLeftChild(it_index->second);
		parent->insertIndexMap(it_index->first, pIndexNode);
		pIndexNode->deleteMap(it_index->first);
		pIndexNode->setParent(parent);//set new link
	}
	else
	{//pIndexNode is not mostleftchild of parent node
		parent->insertIndexMap(it_index->first,pIndexNode);
		pIndexNode->setParent(parent);
		pIndexNode->setMostLeftChild(it_index->second);
		l->setParent(parent);
		map<string, BpTreeNode*>::iterator it_index2;
		it_index2 = parent->getIndexMap()->begin();
		for (; it_index2->first != it_index->first; it_index2++) {}
		it_index2--;
		it_index2->second = l;
		pIndexNode->deleteMap(it_index->first);
	}
	if (!exceedIndexNode(parent))
	{//parent of indexNode don't have to split
		return;
	}
	splitIndexNode(parent);//need to split
}

bool BpTree::exceedDataNode(BpTreeNode* pDataNode){
	//check need split of datanode
	map<string, Characterdata*> *m;
	m = pDataNode->getDataMap();
	if (m->size() < order)
		return false;

	return true;//over size
}

bool BpTree::exceedIndexNode(BpTreeNode* pIndexNode){
	//check need split of indexnode
	map <string, BpTreeNode*>* m = pIndexNode->getIndexMap();
	if (m->size() < order)
		return false;

	return true;//over size
}

void BpTree::SearchRange(string start, string end){
	ofstream fout;
	fout.open("log.txt", ofstream::app);
	BpTreeNode * a = searchDataNode(start);//datanode had start character
	BpTreeNode * b = searchDataNode(end);//datanode had end character 
	map<string, Characterdata*>::iterator it_char;
	map<string, Characterdata*>* m;
	cout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	cout << "                                                       SEARCH " << start << "/" << end << endl;
	cout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	cout << "Name		" << "Pick	" << "Win	" << "WinRatio" << endl;
	fout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	fout << "                                                       SEARCH " << start << "/" << end << endl;
	fout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	fout << "Name		" << "Pick	" << "Win	" << "WinRatio" << endl;
	m = a->getDataMap();
	it_char = m->begin();
	for (; it_char->first != start; it_char++);//find data of start character
	if (start == end)
	{
		printCharacterInfo(it_char->second);
		return;
	}
	for (; it_char != m->end(); it_char++)
	{//print data in datanode of start character from start character
		printCharacterInfo(it_char->second);
	}
	a = a->getNext();
	m = a->getDataMap();
	while (a != b)
	{//print data in datanode where between start character node and end
		for (it_char = m->begin(); it_char != m->end(); it_char++)
		{
			printCharacterInfo(it_char->second);
		}
		a = a->getNext();
		m = a->getDataMap();
	}
	for (it_char = m->begin(); it_char->first != end; it_char++)
	{//print data in datanode of end character before end character
		printCharacterInfo(it_char->second);
	}
	printCharacterInfo(it_char->second);//print data of end charater
	fout.close();
	return;
}

void BpTree::Print(){
	BpTreeNode* pCur = root;
	map<string, Characterdata*>::iterator it_char;
	map<string, Characterdata*>* m;
	ofstream fout;
	fout.open("log.txt", ofstream::app); //declare

	cout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	cout << "                                                       PRINT CHARACTER" << endl;
	cout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	cout << "Name		" << "Pick	" << "Win	" << "WinRatio" << endl;
	fout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	fout << "                                                       PRINT CHARACTER" << endl;
	fout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	fout << "Name		" << "Pick	" << "Win	" << "WinRatio" << endl;
	while (pCur->getMostLeftChild())
	{//find Mostleft dataNode
		pCur = pCur->getMostLeftChild();
	}
	while (pCur)
	{//print all of characterdata in datanode
		m = pCur->getDataMap();
		for (it_char = m->begin(); it_char != m->end(); it_char++)
		{
			printCharacterInfo(it_char->second);
		}
		pCur = pCur->getNext();
	}
	fout.close();
}

void BpTree::printCharacterInfo(Characterdata* pCharacter){
	//print character data in one map
	ofstream fout;
	fout.open("log.txt", ofstream::app);
	cout << pCharacter->getname()<<"		";
	cout << pCharacter->getpick() << "	";
	cout << pCharacter->getwin() << "	";
	cout << pCharacter->getratio() << endl;
	fout << pCharacter->getname() << "		";
	fout << pCharacter->getpick() << "	";
	fout << pCharacter->getwin() << "	";
	fout << pCharacter->getratio() << endl;
	fout.close();
}

void BpTree::printPickRank()                                 
{
	//sorting using maxheap
	BpTreeNode* pCur = root;
	map <string, Characterdata*>*m;
	map<string, Characterdata*>::iterator it_char; //declare
	pair<pair<int, string>, Characterdata*> top; 
	ofstream fout;
	fout.open("log.txt", ofstream::app);
	while (pCur->getMostLeftChild()) pCur = pCur->getMostLeftChild(); //find mostleftchild of datanode
	while (pCur)
	{//visit all of datanode and push data becuz sorting according to pick
		m = pCur->getDataMap();
		it_char = m->begin();
		for (; it_char != m->end(); it_char++)
			pick_heap.push(make_pair(make_pair(it_char->second->getpick(), it_char->first), it_char->second));
		pCur = pCur->getNext();
	}

	cout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	cout << "                                                       PRINT PICK                                    " << endl;
	cout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	cout << "Name		PicK	WinRatio" << endl;
	fout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	fout << "                                                       PRINT PICK                                    " << endl;
	fout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	fout << "Name		PicK	WinRatio" << endl;
	while (!pick_heap.empty())
	{//print all of data in heap
		top = pick_heap.top();
		cout << top.first.second << "		" << top.first.first << "	 " << top.second->getratio() << endl;
		fout << top.first.second << "		" << top.first.first << "		" << top.second->getratio() << endl;
		pick_heap.pop();
	}
	fout.close();

}

void BpTree::printRatioRank()
{
	//sorting using minheap
	BpTreeNode* pCur = root;
	map <string, Characterdata*>*m;
	map<string, Characterdata*>::iterator it_char; //declare
	pair<pair<float, string>, Characterdata*> g_top;
	ofstream fout;
	fout.open("log.txt", ofstream::app);
	while (pCur->getMostLeftChild()) pCur = pCur->getMostLeftChild(); //find mostleftchild of datanode
	while (pCur)
	{//visit all of datanode and push data becuz sorting according to winratio
		m = pCur->getDataMap();
		it_char = m->begin();
		for (; it_char != m->end(); it_char++)
			ratio_heap.push(make_pair(make_pair(it_char->second->getratio(), it_char->first), it_char->second));
		pCur = pCur->getNext();
	}
	cout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	cout << "                                                       PRINT WINRATIO                                    " << endl;
	cout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	cout << "Name		PicK	WinRatio" << endl;
	fout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	fout << "                                                       PRINT WINRATIO                                   " << endl;
	fout << "----------------------------------------------------------------------------------------------------------------------" << endl;
	fout << "Name		PicK	WinRatio" << endl;
	while (!ratio_heap.empty())
	{//print all of data in heap
		g_top = ratio_heap.top();
		cout << g_top.first.second << "		" << g_top.second->getpick() << "	  " << g_top.first.first << endl;
		fout << g_top.first.second << "		" << g_top.second->getpick() << "		 " << g_top.first.first << endl;
		ratio_heap.pop();
	}
	fout.close();
}