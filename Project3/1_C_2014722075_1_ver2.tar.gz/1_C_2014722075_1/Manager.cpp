#include "Manager.h"

using namespace std;

Manager::~Manager()
{
    if (fout.is_open())
        fout.close();

    if (ferr.is_open())
        ferr.close();
}

void Manager::Run(const char* filepath)
{//run : manager command
    fout.open(RESULT_LOG_PATH);
    ferr.open(ERROR_LOG_PATH); //file wrtie
	ifstream fin; //declare file read
	fin.open(filepath);//file open
	if (fin.fail())
	{//command file is not exist
		fout << "====== SYSTEM ======" << endl;
		cout << "====== SYSTEM ======" << endl;
		PrintError(CommandFileNotExist);
		fout << "CommandFileNotExist" << endl;
		cout << "CommandFileNotExist" << endl;
		fout << "=====================" << endl;
		cout << "=====================" << endl; //error
		return;
	}
	Result result;
	char* l = new char[50];
	char* token = new char[20];
	while (fin.getline(l, 50))
	{//get one line from file
		token = strtok(l, " ");//find command
		if (!strcmp(token, "LOAD"))
		{//LOAD
			token = strtok(NULL, "\n");
			cout << "====== LOAD ======" << endl;
			fout << "====== LOAD ======" << endl;
			if (Load(token) == LoadFileNotExist)
			{//if load file is not exist
				fout << "LoadFileNotExist" << endl;
				cout << "LoadFileNotExist" << endl;
				PrintError(LoadFileNotExist); //error
			}
			else
			{//if load file is exist and success load
				fout << "Success" <<endl;
				cout << "Success" << endl;
				PrintError(Success);
			}
			cout << "===================" << endl;
			fout << "===================" << endl;
		}
		else if (!strcmp(token, "PRINT"))
		{//PRINT
			if (Print() == GraphNotExist)//if graph is not exist
				PrintError(GraphNotExist);
			else
				PrintError(Success);//graph is exist and success print
		}
		else if (!strcmp(token , "DFS"))
		{//DFS
			cout << "====== DFS ======" << endl;
			fout << "====== DFS ======" << endl;
			token = strtok(NULL, " ");
			if (token == NULL)
			{//if Vertex inserted is insufficient  
				cout << "VertexKeyNotExist"<<endl;
				fout << "VertexKeyNotExist" << endl;
				PrintError(VertexKeyNotExist);
				cout << "=================" << endl;
				fout << "=================" << endl;
				continue;
			}
			int start = atoi(token);
			token = strtok(NULL, " ");
			if (token == NULL)
			{//if Vertex inserted is insufficient 
				cout << "VertexKeyNotExist" << endl;
				fout << "VertexKeyNotExist" << endl;
				PrintError(VertexKeyNotExist);
				cout << "=================" << endl;
				fout << "=================" << endl;
				continue;
			}
			int end = atoi(token);

			result = FindPathDfs(start,end); //Find DFS
			PrintError(result);
			cout << endl << "=================" << endl;
			fout << endl << "=================" << endl;
		}
		else if (!strcmp(token, "DIJKSTRA"))
		{//DIJKSTRA
			cout << "====== DIJKSTRA ======" << endl;
			fout << "====== DIJKSTRA ======" << endl;
			token = strtok(NULL, " ");
			if (token == NULL)
			{//if Vertex inserted is insufficient 
				cout << "VertexKeyNotExist" << endl;
				fout << "VertexKeyNotExist" << endl;
				PrintError(VertexKeyNotExist);
				cout << "=================" << endl;
				fout <<"=================" << endl;
				continue;
			}
			int start = atoi(token);
			token = strtok(NULL, "\n");
			if (token == NULL)
			{//if Vertex inserted is insufficient 
				cout << "VertexKeyNotExist" << endl;
				fout << "VertexKeyNotExist" << endl;
				PrintError(VertexKeyNotExist);
				cout <<"=================" << endl;
				fout <<"=================" << endl;
				continue;
			}
			int end = atoi(token);

			result = FindShortestPathDijkstraUsingSet(start, end);
			//Find Dijkstra using set
			PrintError(result);
			cout << endl << "=================" << endl;
			fout << endl << "=================" << endl;
		}
		else if (!strcmp(token, "DIJKSTRAMIN"))
		{//DIJKSTRAMIN
			cout << "====== DIJKSTRAMIN ======" << endl;
			fout << "====== DIJKSTRAMIN ======" << endl;
			token = strtok(NULL, " ");
			if (token == NULL)
			{//if Vertex inserted is insufficient 
				cout << "VertexKeyNotExist" << endl;
				fout << "VertexKeyNotExist" << endl;
				PrintError(VertexKeyNotExist);
				cout  << "=================" << endl;
				fout  << "=================" << endl;
				continue;
			}
			int start = atoi(token);
			token = strtok(NULL, "\n");
			if (token == NULL)
			{//if Vertex inserted is insufficient 
				cout << "VertexKeyNotExist" << endl;
				fout << "VertexKeyNotExist" << endl;
				PrintError(VertexKeyNotExist);
				cout <<  "=================" << endl;
				fout <<  "=================" << endl;
				continue;
			}
			int end = atoi(token);

			result = FindShortestPathDijkstraUsingMinHeap(start, end);
			//Find Dijkstra using MinHeap
			PrintError(result);
			cout << endl << "=================" << endl;
			fout << endl << "=================" << endl;
		}
		else if (!strcmp(token, "BELLMANFORD"))
		{//BELLMANFORD
			cout << "====== BELLMANFORD ======" << endl;
			fout << "====== BELLMANFORD ======" << endl;
			token = strtok(NULL, " ");
			if (token == NULL)
			{//if Vertex inserted is insufficient 
				cout << "VertexKeyNotExist" << endl;
				fout << "VertexKeyNotExist" << endl;
				PrintError(VertexKeyNotExist);
				cout << endl << "=================" << endl;
				fout << endl << "=================" << endl;
				continue;
			}
			int start = atoi(token);
			token = strtok(NULL, "\n");
			if (token == NULL)
			{//if Vertex inserted is insufficient 
				cout << "VertexKeyNotExist" << endl;
				fout << "VertexKeyNotExist" << endl;
				PrintError(VertexKeyNotExist);
				cout << "=================" << endl;
				fout << "=================" << endl;
				continue;
			}
			int end = atoi(token);

			result = FindShortestPathBellmanFord(start, end);
			//Find BellmanFord
			PrintError(result);
			cout << endl << "=================" << endl;
			fout << endl << "=================" << endl;
		}
		else
		{//NonDefinedCommand
			cout << "====== "<<token<<" ======" << endl;
			fout << "====== " << token << " ======" << endl;
			PrintError(NonDefinedCommand);
			fout << "NonDefinedCommand" << endl;
			cout << "NonDefinedCommand" << endl;
			cout << "===================" << endl;
			fout << "===================" << endl;
		}
	}
	delete[] token, l;
	return;


    // TODO: implement
}
void Manager::PrintError(Result result)
{//print error
    ferr << "Error code: " << result << std::endl;
}

/// <summary>
/// make a graph
/// </summary>
///
/// <param name="filepath">
/// the filepath to read to make the graph
/// </param>
///
/// <returns>
/// Result::Success if load is successful.
/// Result::LoadFileNotExist if file is not exist.
/// </returns>
Result Manager::Load(const char* filepath)
{//Load
	ifstream fin;
	fin.open(filepath); //file open
	if (fin.fail())
	{//if load file is not exist
		return LoadFileNotExist;
	}
	char *l = new char[100];
	fin.getline(l, 100); 
	int size = atoi(strtok(l, "\n")); //graph size
	int i; int si = 0; 
	int a = 0;
	int b = 0;
	m_graph.SetSize(size);
	for (i = 0; i != size; i++)
	{//make Vertex in Graph
		m_graph.AddVertex(i);
	}
	while (fin.getline(l, 100))
	{//add Edge
		si = atoi(strtok(l, " ")); //first value
		if (si != 0)
		{//if not 0, add Edge
			m_graph.AddEdge(a, b, si);
		}
		for (b = 1; b != size-1; b++)
		{//between value first and last;
			si = atoi(strtok(NULL, " "));
			if (si != 0)
			{//if not 0, add Edge
				m_graph.AddEdge(a, b, si);
			}
		}
		si = atoi(strtok(NULL, "\n")); //last value
		if (si != 0)
		{//if not 0, add Edge
			m_graph.AddEdge(a, b, si);
		}
		a++; b = 0;
	}
	fin.close(); //file close
	delete[] l;
	return Success;



    // TODO: implement
}

/// <summary>
/// print out the graph as matrix form
/// </summary>
///
/// <returns>
/// Result::Success if the printing is successful
/// Result::GraphNotExist if there is no graph
/// </returns>
Result Manager::Print()
{//print graph
	if (m_graph.Size() == 0)
		return GraphNotExist; //if graph is not exist
	else
	{
		m_graph.Print(fout);
		return Success; //graph is exist and success print
	}
}

/// <summary>
/// find the path from startVertexKey to endVertexKey with DFS (stack)
/// </summary>
///
/// <param name="startVertexKey">
/// the start vertex key
/// </param>
/// <param name="endVertexKey">
/// the end vertex key
/// </param>
///
/// <returns>
/// Result::InvalidVertexKey or Result::GraphNotExist or Result::InvalidAlgorithm if an exception has occurred.
/// Result::Success otherwise.
/// </returns>

Result Manager::FindPathDfs(int startVertexKey, int endVertexKey)
{
	if (m_graph.Size() == 0)
	{//if graph is not exist
		cout << "GraphNotExist";
		fout << "GraphNotExist";
		return GraphNotExist;
	}
	if (m_graph.FindVertex(startVertexKey) == NULL || m_graph.FindVertex(endVertexKey) == NULL)//üũ
	{//if Vertex is not exist
		cout << "InvalidVertexKey";
		fout << "InvalidVertexKey";
		return InvalidVertexKey;
	}
	if (m_graph.IsNegativeEdge() == true)
	{//if graph had -Weight
		cout << "InvalidAlgorithm";
		fout << "InvalidAlgorithm";
		return InvalidAlgorithm;
	}


	vector<int> v;
	v = m_graph.FindPathDfs(startVertexKey,endVertexKey);
	//find DFS
	for (int i = 0; i < v.size(); i++)
	{//print result vector
		cout << v[i] << " ";
		fout << v[i] << " ";
	}

	return Success;
}

/// <summary>
/// find the shortest path from startVertexKey to endVertexKey with Dijkstra using std::set
/// </summary>
///
/// <param name="startVertexKey">
/// the start vertex key
/// </param>
/// <param name="endVertexKey">
/// the end vertex key
/// </param>
///
/// <returns>
/// Result::InvalidVertexKey or Result::GraphNotExist or Result::InvalidAlgorithm if an exception has occurred.
/// Result::Success otherwise.
/// </returns>
Result Manager::FindShortestPathDijkstraUsingSet(int startVertexKey, int endVertexKey)
{
	if (m_graph.Size() == 0)
	{//if graph is not exist
		cout << "GraphNotExist";
		fout << "GraphNotExist";
		return GraphNotExist;
	}
	if (m_graph.FindVertex(startVertexKey) == NULL || m_graph.FindVertex(endVertexKey) == NULL)//üũ
	{//if Vertex is not exist
		cout << "InvalidVertexKey";
		fout << "InvalidVertexKey";
		return InvalidVertexKey;
	}
	if (m_graph.IsNegativeEdge() == true)
	{//if graph had -Weight
		cout << "InvalidAlgorithm";
		fout << "InvalidAlgorithm";
		return InvalidAlgorithm;
	}
	vector<int> v;
	v = m_graph.FindShortestPathDijkstraUsingSet(startVertexKey, endVertexKey);
	//Find dijkstra using set
	for (int i = 0; i < v.size(); i++)
	{//print result vector
		cout << v[v.size() - i - 1] << " ";
		fout << v[v.size() - i - 1] << " ";
	}

	return Success;
}

/// <summary>
/// find the shortest path from startVertexKey to endVertexKey with Dijkstra using MinHeap
/// </summary>
///
/// <param name="startVertexKey">
/// the start vertex key
/// </param>
/// <param name="endVertexKey">
/// the end vertex key
/// </param>
///
/// <returns>
/// Result::InvalidVertexKey or Result::GraphNotExist or Result::InvalidAlgorithm if an exception has occurred.
/// Result::Success otherwise.
/// </returns>
Result Manager::FindShortestPathDijkstraUsingMinHeap(int startVertexKey, int endVertexKey)
{
	if (m_graph.Size() == 0)
	{//if graph is not exist
		cout << "GraphNotExist";
		fout << "GraphNotExist";
		return GraphNotExist;
	}
	if (m_graph.FindVertex(startVertexKey) == NULL || m_graph.FindVertex(endVertexKey) == NULL)//üũ
	{//if Vertex is not exist
		cout << "InvalidVertexKey";
		fout << "InvalidVertexKey";
		return InvalidVertexKey;
	}
	if (m_graph.IsNegativeEdge() == true)
	{//if graph had -Weight
		cout << "InvalidAlgorithm";
		fout << "InvalidAlgorithm";
		return InvalidAlgorithm;
	}
	vector<int> v;
	v = m_graph.FindShortestPathDijkstraUsingMinHeap(startVertexKey,endVertexKey);
	//Find dijkstra using MinHeap
	for (int i = 0; i < v.size(); i++)
	{//print result vector
		cout << v[v.size() - i - 1] << " ";
		fout << v[v.size() - i - 1] << " ";
	}

	return Success;
}

/// <summary>
/// find the shortest path from startVertexKey to endVertexKey with Bellman-Ford
/// </summary>
///
/// <param name="startVertexKey">
/// the start vertex key
/// </param>
/// <param name="endVertexKey">
/// the end vertex key
/// </param>
///
/// <returns>
/// Result::InvalidVertexKey or Result::GraphNotExist or Result::NegativeCycleDetected if exception has occurred.
/// Result::Success otherwise.
/// </returns>
Result Manager::FindShortestPathBellmanFord(int startVertexKey, int endVertexKey)
{
	if (m_graph.Size() == 0)
	{//if graph is not exist
		cout << "GraphNotExist";
		fout << "GraphNotExist";
		return GraphNotExist;
	}
	if (m_graph.FindVertex(startVertexKey) == NULL || m_graph.FindVertex(endVertexKey) == NULL)//üũ
	{//if Vertex is not exist
		cout << "InvalidVertexKey";
		fout << "InvalidVertexKey";
		return InvalidVertexKey;
	}
	vector<int> v;
	v = m_graph.FindShortestPathBellmanFord(startVertexKey, endVertexKey);
	//Find BellamnFord
	if (v.size() == 0)//if graph had -Weight
	{
		cout << "NegativeCycleDetected ";
		fout << "NegativeCycleDetected ";
		return NegativeCycleDetected;
	}
	for (int i = 0; i < v.size(); i++)
	{//print result vector
		cout << v[v.size() - i - 1] << " ";
		fout << v[v.size() - i - 1] << " ";
	}

	return Success;
}
