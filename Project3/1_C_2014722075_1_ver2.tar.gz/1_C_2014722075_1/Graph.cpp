#include "Graph.h"
#include "Stack.h"
#include "MinHeap.h"
#include <set>
#include <iostream>

using namespace std;

#define DFS_FIRST_PATH

Graph::Graph()
{
	m_pVHead = NULL;
	m_vSize = 0;
}
Graph::~Graph()
{
	Clear();
}

void Graph::AddVertex(int vertexKey)
{//add vertex 
	Vertex* p = m_pVHead;
	Vertex* n_p = new Vertex(vertexKey);
	if (p == NULL)
	{//if head vertex is empty
		m_pVHead = n_p;
		return;
	}
	while (p->GetNext())
	{//else
		p = p->GetNext();
	}
	p->SetNext(n_p);
	return;
}

void Graph::AddEdge(int startVertexKey, int endVertexKey, int weight)
{//add edge
	Vertex* p = FindVertex(startVertexKey);
	p->AddEdge(endVertexKey, weight);
	p->AddSize();//size++
	return;
}

Vertex* Graph::FindVertex(int key)
{//find vertex
	Vertex *p = m_pVHead;
	while (p)
	{
		if (p->GetKey() == key)
			return p;//if find!
		p = p->GetNext();
	}
return NULL;//cant find
}

void Graph::SetSize(int n)
{//set size of graph
	m_vSize = n;
}

int Graph::Size() const
{//return graph size
	return m_vSize;
}

void Graph::Clear()
{//delete all of graph
	Vertex* p = m_pVHead;
	Vertex* d;

	while (p)
	{
		d = p;
		p = p->GetNext();
		d->Clear();
		delete d; //delete vertex
	}
}

void Graph::Print(std::ofstream& fout)
{//print graph
	ifstream fin;
	fin.open("mapdata.txt");
	char* l = new char[100];
	fin.getline(l, 100);
	fout << "====== PRINT ====== " << endl;
	cout << "====== PRINT ====== " << endl;
	while (fin.getline(l, 100))
	{//print all of graph
		fout << l << endl;
		cout << l << endl;
	}
	fout << "===================" << endl;
	cout << "===================" << endl;
	delete[] l;
}

bool Graph::IsNegativeEdge()
{//check -Weight of all of Edge
	Vertex* p = m_pVHead;
	Edge* E = NULL;
	while (p)
	{
		E = p->GetHeadOfEdge();
		while (E)
		{
			if (E->GetWeight() < 0)
				return true; //exist -Weight
			E = E->GetNext();
		}
		p = p->GetNext();
	}
	return false; //Not exist -Weight
}

std::vector<int> Graph::FindPathDfs(int startVertexKey, int endVertexKey)
{//Find path using DFS
	Vertex* p = FindVertex(startVertexKey); //find start vertex
	Vertex* c;
	Edge* f;
	Stack<int> s; //declare stack
	int tw = 0;
	//make visit table
	bool *visit_t = new bool[m_vSize];
	for (int i = 0; i < m_vSize; i++)
		visit_t[i] = false; //innitialize visit table
	s.Push(p->GetKey()); //push start vertex
	vector<int> v;
	v.push_back(p->GetKey());  //push back start vertex
	visit_t[p->GetKey()] = true; //visit start vertex
	s.Pop(); //pop start vertex
	while (v.back() != endVertexKey)
	{
		Edge* e = p->GetHeadOfEdge();
		while (e)
		{//visit all of edge of vertex(p)
			if (visit_t[e->GetKey()] == false)
			{//if visit of edge of p(vertex) is false(not visit) 
				s.Push(e->GetKey()); //stack push
			}
			else
			{//true
				c = FindVertex(e->GetKey());
				f = c->GetHeadOfEdge();
				while (f)
				{
					int ch = 0;
					for (int y = 0; y < v.size(); y++)
					{
						if (v[y] == c->GetKey())
							ch = 1;
					}
					if (visit_t[f->GetKey()] == false && ch == 0)
					{//if exist not visit vertex and not circular
						s.Push(e->GetKey());
						break;
					}
					f = f->GetNext();
				}
			}
			e = e->GetNext();
		}
		int a = s.Top(); //take Top of stack
		s.Pop(); //delete Top of stack
		e = p->GetHeadOfEdge(); 
		while (e)
		{//find last vertex pushed stack
			if (e->GetKey() == a)
			{
				tw = tw + e->GetWeight();
			}
			e = e->GetNext();
		}
		p = FindVertex(a); //find next vertex
		visit_t[p->GetKey()] = true; //make true
		v.push_back(p->GetKey());
		int check = 0;
		if (p->GetHeadOfEdge() != NULL && p->GetKey() != endVertexKey)
		{//check vertex dont have next path
			e = p->GetHeadOfEdge();
			while (e)
			{
				if (visit_t[e->GetKey()] == false)
					break;;
				e = e->GetNext();
			}
			if (e == NULL)//child is all true
			{
				check = 1;
			}
		}
		if ((p->GetHeadOfEdge() == NULL && v.back()!= endVertexKey)||check == 1)
		{//if vertex dont have next path
			v.clear();//clear vector
			p = FindVertex(startVertexKey);
			tw = 0;
			v.push_back(p->GetKey()); //push vertext
		}
	}
	v.push_back(tw); //push total weight in vector
	delete[] visit_t;
	return v;
}

std::vector<int> Graph::FindShortestPathDijkstraUsingSet(int startVertexKey, int endVertexKey)
{//Find Shortest Path using Dijkstra wite Set
	vector<int> v;
	set<int,less<int>> s; //declare set
	Vertex* p = FindVertex(startVertexKey); //find start vertex
	Vertex* c;
	Edge* f;
	int i;
	int* dis = new int[m_vSize];
	int* visit = new int[m_vSize];
	int* path = new int[m_vSize]; //make table
	for (i = 0; i < m_vSize; i++)
	{
		dis[i] = 11111111;
		visit[i] = 0;
		path[i] = -1; //initializing
	}
	dis[startVertexKey] = 0; 
	while (1)
	{
		f = p->GetHeadOfEdge();
		visit[p->GetKey()] = 1;
		while (f)
		{
			if (dis[f->GetKey()] > f->GetWeight() + dis[p->GetKey()])
			{//if need update distance
				if (s.find(dis[f->GetKey()]) != s.end())
				{//if exist distance in set
					s.erase(dis[f->GetKey()]); //erase index in set
					v.push_back(dis[p->GetKey()] + f->GetWeight());//push new distance
				}

				dis[f->GetKey()] = f->GetWeight() + dis[p->GetKey()];//update
				path[f->GetKey()] = p->GetKey();
				if (visit[f->GetKey()] == 0)
					v.push_back(dis[f->GetKey()]);
			}
			f = f->GetNext();
		}
		s.insert(v.begin(), v.end()); //insert vector in set
		int g = 0;
		if(s.size() != 0 )
			g = *s.begin(); //find shortest path
		for (i = 0; i < m_vSize; i++)
		{
			if (dis[i] == g)
			{
				s.erase(g); //erase
				break;
			}
		}
		p = FindVertex(i);
		v.clear();
		if (checkvisittable(visit) == true || (s.size() == 0 && visit[endVertexKey] == 1))
			break; //if visit table is all true or set size = 0 and visited endvertex
	}
	v.push_back(dis[endVertexKey]); //push total distance in vector
	v.push_back(endVertexKey); //push path
	while (endVertexKey != startVertexKey)
	{//push path
		p = FindVertex(path[endVertexKey]);
		endVertexKey = p->GetKey();
		v.push_back(endVertexKey);
	}
	delete[] dis, visit, path;
	return v;

}


std::vector<int> Graph::FindShortestPathDijkstraUsingMinHeap(int startVertexKey, int endVertexKey)
{
	vector<int> v;
	MinHeap<int,int> h; //declare Minheap
	Vertex* p = FindVertex(startVertexKey); //find start vertex
	Edge* f;
	int i;
	int* dis = new int[m_vSize];
	int* visit = new int[m_vSize];
	int* path = new int[m_vSize]; //make table
	for (i = 0; i < m_vSize; i++)
	{
		dis[i] = 11111111;
		visit[i] = 0;
		path[i] = -1;//initializing
	}
	dis[startVertexKey] = 0;
	while (1)
	{
		f = p->GetHeadOfEdge();
		visit[p->GetKey()] = 1;
		while (f)
		{
			if (dis[f->GetKey()] > f->GetWeight() + dis[p->GetKey()])
			{//if need update distance
				if (h.Get(dis[f->GetKey()]).first != -1)
				{
					h.DecKey(f->GetKey(), f->GetWeight() + dis[p->GetKey()]);
				}//replace new distance
				dis[f->GetKey()] = f->GetWeight() + dis[p->GetKey()];
				path[f->GetKey()] = p->GetKey();//update
				if (visit[f->GetKey()] == 0)
					h.Push(dis[f->GetKey()],f->GetKey());
			}
			f = f->GetNext();
		}
		int g = 0;
		if (h.IsEmpty() != true)
			g = h.Top().second; // find shortest path
		h.Pop();
		p = FindVertex(g);
		v.clear();
		if (checkvisittable(visit) == true || (h.IsEmpty() && visit[endVertexKey] == 1))
			break;//if visit table is all true or heap size = 0 and visited envertex
	}
	v.push_back(dis[endVertexKey]);//push total distance in vector
	v.push_back(endVertexKey); //push path
	while (endVertexKey != startVertexKey)
	{//push path
		p = FindVertex(path[endVertexKey]);
		endVertexKey = p->GetKey();
		v.push_back(endVertexKey);
	}
	delete[] dis, visit, path;
	return v;

}

std::vector<int> Graph::FindShortestPathBellmanFord(int startVertexKey, int endVertexKey)
{
	vector<int> v;
	Vertex* p = m_pVHead; 
	Edge* f;
	int i;
	int* dis = new int[m_vSize];
	int* dis2 = new int[m_vSize];
	int* path = new int[m_vSize];//make table
	for (i = 0; i < m_vSize; i++)
	{
		dis[i] = 11111111;
		dis2[i] = 11111111;
		path[i] = -1; //initialing
	}
	dis[startVertexKey] = 0;
	dis2[startVertexKey] = 0; //it will use find -weight
	int count = 0; int count2 = 0;
	while (count != m_vSize-1)
	{//doing size*size-1
		while (count2 != m_vSize)
		{//doing size
			if (dis[p->GetKey()] != 11111111)
			{//if distance is infinity, dont need visit
				f = p->GetHeadOfEdge();
				while (f)
				{
					if (dis[f->GetKey()] > dis[p->GetKey()] + f->GetWeight())
					{//if need update
						dis[f->GetKey()] = dis[p->GetKey()] + f->GetWeight();
						dis2[f->GetKey()] = dis2[p->GetKey()] + f->GetWeight();
						path[f->GetKey()] = p->GetKey();
					}
					f = f->GetNext();
				}
			}
			count2++;//count2 += 1
			p = p->GetNext();
		}
		count2 = 0;
		count++; //count += 1
		p = m_pVHead;
	}
	p = m_pVHead;
	count = 0;count2 = 0;
	//find -weight, use only distance table 2
	//same process
	while (count != m_vSize - 1)
	{
		while (count2 != m_vSize)
		{
			if (dis2[p->GetKey()] != 11111111)
			{
				f = p->GetHeadOfEdge();
				while (f)
				{
					if (dis2[f->GetKey()] > dis2[p->GetKey()] + f->GetWeight())
					{
						dis2[f->GetKey()] = dis2[p->GetKey()] + f->GetWeight();
						path[f->GetKey()] = p->GetKey();
					}
					f = f->GetNext();
				}
			}
			count2++;
			p = p->GetNext();
		}
		count2 = 0;
		count++;
		p = m_pVHead;
	}
	//find -weight, if dis != dis2 (update more), graph have - weight
	for (int j = 0; j < m_vSize ; j++)
	{
		if (dis[j] != dis2[j])
		{
			v.clear();//clear vector
			return v; //if exist -weight return 0 vector
		}
	}
	v.push_back(dis[endVertexKey]); //push total distance
	while (endVertexKey != -1)
	{//push path
		v.push_back(endVertexKey);
		endVertexKey = path[endVertexKey];
	}
	return v;

	delete[] dis, dis2, path;
}